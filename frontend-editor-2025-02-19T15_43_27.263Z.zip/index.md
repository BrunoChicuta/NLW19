#HTML 

- HyperText ("super" texto)

- Markup (Marcacao)
  - tags
  - atributos
 
- Language (Linguagem)



#CSS

- Cascading
- Style
- Sheet


# JavaScript
- Linguagem Interpretada pelo Browser
- Multiparadigma
 

